# 🔐 Skill: Firebase Auth (Kullanıcı Doğrulama)

> Bu skill dosyasını Auth ile ilgili her sohbetin başına PROJECT_CONTEXT.md ile birlikte yapıştır.

---

## Bu Skill Ne İçin?
Firebase Authentication ile kullanıcı kaydı, girişi ve oturum yönetimini Flutter'da uygulamak için.

---

## Paketler
```yaml
firebase_auth: ^5.x.x        # Firebase Auth
google_sign_in: ^6.x.x       # Google ile giriş
cloud_firestore: ^5.x.x      # Kullanıcı profilini kaydet
flutter_riverpod: ^2.x.x     # State management
```

---

## Mevcut Yapı
```
lib/features/auth/
├── data/
│   └── auth_repository.dart      # Firebase ile iletişim
├── domain/
│   └── user_model.dart           # Kullanıcı veri modeli
└── presentation/
    ├── login_screen.dart
    ├── register_screen.dart
    └── auth_controller.dart      # Riverpod provider
```

---

## Kullanıcı Modeli
```dart
// lib/features/auth/domain/user_model.dart
class UserModel {
  final String uid;
  final String displayName;
  final String email;
  final String? photoUrl;
  final GeoPoint? location;
  final String? geohash;
  final double rating;
  final int ratingCount;
  final DateTime createdAt;
  final bool isVerified;
}
```

---

## Auth Repository Yapısı
```dart
// lib/features/auth/data/auth_repository.dart
// İçermesi gerekenler:
// - signInWithGoogle()
// - signInWithEmail(email, password)
// - registerWithEmail(email, password, displayName)
// - signOut()
// - authStateChanges stream
// - Firestore'a kullanıcı profili kaydetme (ilk girişte)
```

---

## Firestore Security Rules (Auth için)
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

---

## Sık Karşılaşılan Sorunlar
- **SHA-1 fingerprint:** Google Sign-In için Firebase konsoluna eklenmiş olmalı
- **iOS GoogleService-Info.plist:** Runner klasörüne eklenmiş olmalı
- **Android google-services.json:** android/app/ klasöründe olmalı

---

## Yapay Zekadan İstek Örneği
```
"PROJECT_CONTEXT.md ve skill_auth.md dosyalarına göre,
Firebase Auth ile Google Sign-In'i Riverpod kullanarak 
Flutter'da nasıl implement ederim? 
Mevcut yapım: lib/features/auth/data/auth_repository.dart"
```
