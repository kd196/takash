# 🔁 Takaş — Proje Bağlam Dosyası
> Bu dosyayı her yeni yapay zeka sohbetinin BAŞINA yapıştır.

---

## 📌 Proje Özeti
**Takaş**, konum tabanlı bir mobil takas platformudur. Kullanıcılar mahallelerindeki insanlarla para kullanmadan eşya ve yetenek takası yaparlar.

- **Hedef Kitle:** 18–40 yaş arası, sürdürülebilirliğe duyarlı şehirli kullanıcılar
- **Platform:** iOS + Android (Flutter ile tek kod tabanı)
- **MVP Odak Şehri:** [Şehir adını buraya yaz]
- **Geliştirici Seviyesi:** Başlangıç — yapay zeka yardımıyla geliştiriliyor

---

## ⚙️ Teknoloji Yığını (Tech Stack)

| Katman | Teknoloji | Versiyon | Notlar |
|---|---|---|---|
| Mobil | Flutter | 3.x | iOS + Android |
| Auth | Firebase Auth | Latest | Google, E-posta, Telefon |
| Veritabanı | Cloud Firestore | Latest | NoSQL, realtime |
| Depolama | Firebase Storage | Latest | Fotoğraf & medya |
| Konum | Mapbox SDK | Latest | Geofencing, harita |
| Chat | Stream Chat SDK | Latest | Realtime mesajlaşma |
| Backend | Firebase Cloud Functions | Latest | Serverless |
| State Mgmt | Riverpod | 2.x | Flutter state yönetimi |

---

## 📁 Klasör Yapısı

```
lib/
├── main.dart
├── app/
│   ├── router.dart              # GoRouter navigation
│   └── theme.dart               # Uygulama teması
├── core/
│   ├── constants/               # API keys, config
│   ├── utils/                   # Yardımcı fonksiyonlar
│   └── extensions/              # Dart extensions
├── features/
│   ├── auth/                    # Giriş / kayıt
│   │   ├── data/
│   │   ├── domain/
│   │   └── presentation/
│   ├── listings/                # İlanlar
│   │   ├── data/
│   │   ├── domain/
│   │   └── presentation/
│   ├── chat/                    # Mesajlaşma
│   │   ├── data/
│   │   ├── domain/
│   │   └── presentation/
│   ├── map/                     # Harita & geofencing
│   │   ├── data/
│   │   ├── domain/
│   │   └── presentation/
│   └── profile/                 # Profil & puanlama
│       ├── data/
│       ├── domain/
│       └── presentation/
└── shared/
    ├── widgets/                 # Ortak widgetlar
    ├── models/                  # Paylaşılan modeller
    └── services/                # Firebase servisleri
```

---

## 🗄️ Firestore Koleksiyon Yapısı

```
users/{userId}
  - displayName: string
  - email: string
  - photoUrl: string
  - location: GeoPoint
  - geohash: string           ← Geofencing için kritik
  - rating: number (0-5)
  - ratingCount: number
  - createdAt: timestamp
  - isVerified: boolean

listings/{listingId}
  - ownerId: string           ← users/{userId}
  - title: string
  - description: string
  - category: string          ← enum: electronics, clothing, books...
  - imageUrls: string[]
  - wantedItem: string        ← "Bu eşya karşılığında şunu istiyorum"
  - location: GeoPoint
  - geohash: string           ← Geofencing için kritik
  - status: string            ← enum: active, reserved, completed
  - createdAt: timestamp

chats/{chatId}
  - participants: string[]    ← [userId1, userId2]
  - listingId: string
  - lastMessage: string
  - lastMessageAt: timestamp
  - createdAt: timestamp

ratings/{ratingId}
  - fromUserId: string
  - toUserId: string
  - listingId: string
  - score: number (1-5)
  - comment: string
  - createdAt: timestamp
```

---

## 📱 Ekranlar & Navigasyon

```
Splash → Onboarding → Auth (Giriş/Kayıt)
  ↓
Ana Sayfa (Tab Bar)
  ├── 🏠 Keşfet     → İlan listesi (geofenced)
  ├── 🗺️ Harita     → Yakın ilanlar haritada
  ├── ➕ İlan Ver   → Yeni ilan oluştur
  ├── 💬 Sohbetler  → Chat listesi
  └── 👤 Profil     → Kullanıcı profili & ayarlar

İlan Detay → Teklif Ver → Sohbet → Takas Tamamla → Puanlama
```

---

## 🚦 Geliştirme Aşamaları

- **Faz 1:** Auth + Profil (Temel altyapı)
- **Faz 2:** İlan Yönetimi (CRUD)
- **Faz 3:** Konum & Harita (Geofencing)
- **Faz 4:** Chat (Stream Chat entegrasyonu)
- **Faz 5:** Puanlama & Güven Sistemi
- **Faz 6:** Bildirimler & Polish
- **Faz 7:** Test & Beta

**Şu an hangi fazdayım:** [Buraya yaz]
**Şu an çalıştığım özellik:** [Buraya yaz]

---

## ⚠️ Önemli Kurallar (AI'ya her sohbette hatırlat)
1. Tüm Flutter paketleri `pub.dev`'den güncel versiyonla kullanılacak
2. State yönetimi için **sadece Riverpod** kullanılacak, başka bir şey önerme
3. Geofencing için Firestore'da **geohash** yaklaşımı kullanılacak
4. Her özellik `features/` altında kendi klasöründe olacak (clean architecture)
5. Türkçe yorum satırları kullan, değişken isimleri İngilizce
