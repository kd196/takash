# 🗺️ Skill: Mapbox & Geofencing (Konum Sistemi)

> Bu skill dosyasını harita ve konum ile ilgili her sohbetin başına PROJECT_CONTEXT.md ile birlikte yapıştır.

---

## Bu Skill Ne İçin?
Mapbox harita entegrasyonu, kullanıcı konumu alma ve geofencing ile yakın ilanları filtreleme.

---

## Paketler
```yaml
mapbox_maps_flutter: ^2.x.x
geolocator: ^13.x.x
permission_handler: ^11.x.x
```

---

## Mapbox API Key Yapılandırması

**Android** — `android/app/src/main/AndroidManifest.xml`:
```xml
<meta-data
  android:name="com.mapbox.token"
  android:value="pk.YOUR_MAPBOX_TOKEN" />
```

**iOS** — `ios/Runner/Info.plist`:
```xml
<key>MBXAccessToken</key>
<string>pk.YOUR_MAPBOX_TOKEN</string>
```

> ⚠️ Token'ı asla GitHub'a push etme! `.env` veya `--dart-define` kullan.

---

## Geofencing Yaklaşımı (Geohash)

Firestore'da konum bazlı sorgu yapmak için **geohash** kullanılır.
Firestore native olarak "yakınlık sorgusunu" desteklemez, geohash bunu çözer.

```dart
// Geohash hesaplama
// pubspec.yaml: geoflutterfire_plus: ^0.0.x
import 'package:geoflutterfire_plus/geoflutterfire_plus.dart';

// İlan kaydederken
final GeoFirePoint geoPoint = GeoFirePoint(GeoPoint(lat, lng));
final String geohash = geoPoint.geohash;

// Kaydet
await firestore.collection('listings').add({
  'location': GeoPoint(lat, lng),
  'geohash': geohash,
  // ... diğer alanlar
});
```

---

## Yakın İlan Sorgulama
```dart
// 10 km içindeki aktif ilanlar
final GeoCollectionReference<Map<String, dynamic>> geoRef = 
  GeoCollectionReference(firestore.collection('listings'));

final Stream<List<DocumentSnapshot>> stream = geoRef.subscribeWithin(
  center: GeoFirePoint(GeoPoint(userLat, userLng)),
  radiusInKm: 10,
  field: 'location',
  geopointFrom: (data) => data['location'] as GeoPoint,
  queryBuilder: (query) => query.where('status', isEqualTo: 'active'),
);
```

---

## Kullanıcı Konum İzni
```dart
// Konum izni iste
LocationPermission permission = await Geolocator.requestPermission();

// Konum al
Position position = await Geolocator.getCurrentPosition(
  desiredAccuracy: LocationAccuracy.high,
);
```

---

## Mevcut Yapı
```
lib/features/map/
├── data/
│   ├── location_service.dart      # Konum alma, izin
│   └── geo_repository.dart        # Geohash, sorgular
├── domain/
│   └── geo_point_model.dart
└── presentation/
    ├── map_screen.dart            # Mapbox harita
    └── map_controller.dart        # Riverpod
```

---

## Yapay Zekadan İstek Örneği
```
"PROJECT_CONTEXT.md ve skill_03_map.md dosyalarına göre,
map_screen.dart ekranını oluştur.
Ekranda Mapbox haritası olsun, kullanıcının konumunu merkez alsın,
10 km içindeki aktif ilanları marker olarak göstersin.
Bir marker'a tıklanınca ilan özeti bottom sheet olarak açılsın."
```
