# 💬 Skill: Stream Chat (Mesajlaşma Sistemi)

> Bu skill dosyasını chat ile ilgili her sohbetin başına PROJECT_CONTEXT.md ile birlikte yapıştır.

---

## Bu Skill Ne İçin?
Stream Chat SDK ile Flutter'da gerçek zamanlı mesajlaşma sistemi kurmak.

---

## Paketler
```yaml
stream_chat_flutter: ^9.x.x       # UI + logic hepsi dahil
stream_chat_flutter_core: ^9.x.x  # Sadece logic (UI kendin yapacaksan)
```

---

## Stream Dashboard Kurulumu
1. getstream.io adresine git ve ücretsiz hesap oluştur
2. Yeni bir App oluştur → API Key'i al
3. App ID ve API Key'i projeye ekle (`.env` veya `--dart-define`)

---

## Mimari

### Token Üretimi (Firebase Cloud Function)
Stream Chat, kullanıcılar için **server-side token** üretimi gerektirir.
Bu token Firebase Cloud Function ile üretilir:

```javascript
// functions/index.js
const { StreamChat } = require('stream-chat');

exports.getStreamToken = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated');
  
  const client = StreamChat.getInstance(
    process.env.STREAM_API_KEY,
    process.env.STREAM_API_SECRET
  );
  
  const token = client.createToken(context.auth.uid);
  return { token };
});
```

### Flutter'da Stream Başlatma
```dart
// lib/shared/services/stream_chat_service.dart
class StreamChatService {
  static const _apiKey = 'YOUR_STREAM_API_KEY';
  late StreamChatClient client;
  
  Future<void> initialize(UserModel user) async {
    client = StreamChatClient(_apiKey);
    
    // Firebase Cloud Function'dan token al
    final tokenResult = await FirebaseFunctions.instance
      .httpsCallable('getStreamToken')
      .call();
    
    await client.connectUser(
      User(
        id: user.uid,
        name: user.displayName,
        image: user.photoUrl,
      ),
      tokenResult.data['token'],
    );
  }
  
  Future<void> disconnect() async {
    await client.disconnectUser();
  }
}
```

---

## Sohbet Başlatma (İlan Sahibine Teklif)
```dart
// İki kullanıcı arasında sohbet kanalı oluştur
Future<Channel> createOrGetChannel({
  required String currentUserId,
  required String otherUserId,
  required String listingId,
}) async {
  final channelId = [currentUserId, otherUserId, listingId]
    ..sort();
  
  final channel = client.channel(
    'messaging',
    id: channelId.join('_'),
    extraData: {
      'listingId': listingId,
      'members': [currentUserId, otherUserId],
    },
  );
  
  await channel.watch();
  return channel;
}
```

---

## Mevcut Yapı
```
lib/features/chat/
├── data/
│   └── chat_repository.dart       # Stream channel operasyonları
├── domain/
│   └── chat_model.dart
└── presentation/
    ├── chat_list_screen.dart      # Tüm sohbetler
    ├── chat_detail_screen.dart    # Tek sohbet (Stream UI)
    └── chat_controller.dart       # Riverpod
```

---

## Önemli Notlar
- Stream Chat, Flutter için hazır UI bileşenleri sunar (`StreamMessageListView`, `StreamMessageInput`)
- Bu bileşenler kullanılırsa chat ekranı çok hızlı kurulur
- Özel tasarım istersen `stream_chat_flutter_core` kullan ve UI'ı kendin yaz

---

## Yapay Zekadan İstek Örneği
```
"PROJECT_CONTEXT.md ve skill_04_chat.md dosyalarına göre,
chat_detail_screen.dart ekranını oluştur.
Stream Chat Flutter SDK'nın hazır UI bileşenlerini kullan.
Ekranın üstünde ilan sahibinin adı ve ilanın başlığı olsun."
```
