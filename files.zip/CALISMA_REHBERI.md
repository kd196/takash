# 🤖 Yapay Zeka ile Çalışma Rehberi
## (Agentic Workflow Kullanım Kılavuzu)

---

## Bu Sistem Nedir?

Sen yapay zekayı bir **asistan geliştirici** gibi kullanacaksın.
Ama yapay zekanın her sohbette hafızası sıfırlanır — bu dosyalar onun "hafızası" olacak.

Her sohbette doğru dosyaları yapıştırırsan, yapay zeka projenin tamamını biliyor gibi davranır ve çok daha iyi kod üretir.

---

## Dosyaların Görevi

| Dosya | Ne Zaman Kullanılır |
|---|---|
| `PROJECT_CONTEXT.md` | **Her sohbetin başında** — her zaman |
| `DEVELOPMENT_PLAN.md` | Ne yapacağını planlarken |
| `skills/skill_01_auth.md` | Auth kodu yazarken |
| `skills/skill_02_listings.md` | İlan kodu yazarken |
| `skills/skill_03_map.md` | Harita/konum kodu yazarken |
| `skills/skill_04_chat.md` | Chat kodu yazarken |
| `skills/skill_05_rating.md` | Puanlama kodu yazarken |

---

## Nasıl Kullanılır? (Adım Adım)

### Senaryo: İlan oluşturma ekranı yapmak istiyorsun

**1. Yeni bir sohbet aç**

**2. Şunu yapıştır:**
```
--- PROJE BAĞLAMI ---
[PROJECT_CONTEXT.md içeriğini buraya yapıştır]

--- İLAN SKILL ---
[skill_02_listings.md içeriğini buraya yapıştır]
--- BAĞLAM SONU ---

Şimdi bana şunu yap:
create_listing_screen.dart ekranını oluştur.
Ekranda: başlık input, açıklama input, kategori dropdown (ListingCategory enum),
maksimum 5 fotoğraf seçme (image_picker), ve "karşılığında ne istiyorum" inputu olsun.
Riverpod ile state yönetimi yap. Kaydet butonuna basınca listing_repository'yi çağır.
```

**3. Yapay zekanın ürettiği kodu al, kopyala, dosyaya yapıştır**

**4. Hata alırsan aynı sohbette devam et:**
```
Şu hatayı aldım:
[hata mesajını yapıştır]

Düzelt.
```

---

## Altın Kurallar

### ✅ Yap
- Her sohbette PROJECT_CONTEXT.md'yi yapıştır
- İlgili skill dosyasını da ekle
- Tek seferde tek bir ekran veya özellik iste
- Hata aldığında aynı sohbette düzeltmesini iste
- "Bunu neden böyle yaptın?" diye sor, öğren

### ❌ Yapma
- "Tüm uygulamayı yaz" deme — çok geniş, kalitesiz çıkar
- Üretilen kodu anlamadan kopyalama
- Paket versiyonlarını kontrol etmeden kullanma
- Aynı sohbette çok farklı konulara geçme

---

## İstek Yazma Şablonları

### Yeni ekran oluştururken:
```
[Bağlam dosyaları yapıştırıldı]

[ekran_adı].dart dosyasını oluştur.
Bu ekranda şunlar olmalı: [liste]
State yönetimi: Riverpod
Stil: Material Design 3
Navigasyon: GoRouter
```

### Hata düzeltirken:
```
[Bağlam dosyaları yapıştırıldı]

Şu dosyada hata var: [dosya_adı].dart
Hata: [hata mesajı]
Mevcut kod:
[kodu yapıştır]

Düzelt ve açıkla.
```

### Öğrenmek istediğinde:
```
[Bağlam dosyaları yapıştırıldı]

[konu] nedir ve neden bu yaklaşımı kullandık?
Basit bir örnek ver.
```

---

## Yapay Zeka Modeli Seçimi

| Model | Ne Zaman Kullan |
|---|---|
| **Claude Sonnet** | Günlük kod yazma, hata düzeltme |
| **Claude Opus** | Karmaşık mimari kararlar, zor buglar |

---

## Haftalık Rutin Önerisi

| Gün | Ne Yapılır |
|---|---|
| Pazartesi | DEVELOPMENT_PLAN.md'ye bak, o hafta ne yapacağını planla |
| Salı-Perşembe | Günde 1-2 özellik implement et |
| Cuma | Yazdıklarını test et, hataları düzelt |
| Cumartesi | DEVELOPMENT_PLAN.md'deki tamamlananları işaretle |

---

## Skill Dosyalarını Güncelleme

Bir özelliği bitirince **o skill dosyasına notlar ekle:**
```markdown
## ✅ Tamamlandı (Tarih: XX/XX/XXXX)
- create_listing_screen.dart oluşturuldu
- listing_repository.dart yazıldı
- Karşılaşılan sorun: image_picker iOS izni
- Çözüm: Info.plist'e NSPhotoLibraryUsageDescription eklendi
```

Bu notlar ileride aynı konuya döndüğünde çok işe yarar.
