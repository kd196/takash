# ⭐ Skill: Puanlama & Güven Sistemi

> Bu skill dosyasını puanlama ile ilgili her sohbetin başına PROJECT_CONTEXT.md ile birlikte yapıştır.

---

## Bu Skill Ne İçin?
Takas sonrası karşılıklı puanlama ve topluluk güven sistemini implement etmek.

---

## İş Mantığı
1. İki taraf da sohbet içinde "Takas Tamamlandı" butonuna basar
2. Her iki taraf da onayladığında ilan "completed" statüsüne geçer
3. Her kullanıcıya puanlama ekranı açılır
4. Puan Firestore'a kaydedilir
5. Firebase Cloud Function kullanıcının ortalama puanını günceller

---

## Veri Modeli
```dart
// lib/features/profile/domain/rating_model.dart
class RatingModel {
  final String id;
  final String fromUserId;
  final String toUserId;
  final String listingId;
  final int score;           // 1-5
  final String? comment;
  final DateTime createdAt;
}
```

---

## Firestore Yapısı
```
ratings/{ratingId}
  - fromUserId: string
  - toUserId: string
  - listingId: string
  - score: number
  - comment: string
  - createdAt: timestamp

users/{userId}
  - rating: number        ← ortalama puan (Cloud Function günceller)
  - ratingCount: number   ← toplam değerlendirme sayısı
```

---

## Cloud Function — Ortalama Puan Güncelleme
```javascript
// functions/index.js
exports.onRatingCreated = functions.firestore
  .document('ratings/{ratingId}')
  .onCreate(async (snap, context) => {
    const rating = snap.data();
    const userRef = admin.firestore().doc(`users/${rating.toUserId}`);
    
    return admin.firestore().runTransaction(async (transaction) => {
      const userDoc = await transaction.get(userRef);
      const userData = userDoc.data();
      
      const newCount = (userData.ratingCount || 0) + 1;
      const newRating = ((userData.rating || 0) * (newCount - 1) + rating.score) / newCount;
      
      transaction.update(userRef, {
        rating: newRating,
        ratingCount: newCount,
      });
    });
  });
```

---

## Repository Metodları
```dart
Future<void> submitRating(RatingModel rating)
Future<bool> hasUserRatedListing(String fromUserId, String listingId)
Stream<List<RatingModel>> getUserRatings(String userId)
Future<void> markListingCompleted(String listingId, String userId)  
// Her iki taraf da işaretlediğinde completed olur
```

---

## Mevcut Yapı
```
lib/features/profile/
├── data/
│   ├── profile_repository.dart
│   └── rating_repository.dart
├── domain/
│   ├── rating_model.dart
│   └── user_model.dart
└── presentation/
    ├── profile_screen.dart
    ├── rating_screen.dart         # Takas sonrası puanlama
    └── profile_controller.dart
```

---

## Yapay Zekadan İstek Örneği
```
"PROJECT_CONTEXT.md ve skill_05_rating.md dosyalarına göre,
rating_screen.dart ekranını oluştur.
Kullanıcı 1-5 yıldız seçebilmeli ve isteğe bağlı yorum yazabilmeli.
Gönder butonuna basınca Firestore'a kaydet ve ana sayfaya yönlendir."
```
