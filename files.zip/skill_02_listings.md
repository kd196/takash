# 📦 Skill: İlan Yönetimi (Listings)

> Bu skill dosyasını ilan ile ilgili her sohbetin başına PROJECT_CONTEXT.md ile birlikte yapıştır.

---

## Bu Skill Ne İçin?
İlan oluşturma, listeleme, filtreleme ve CRUD işlemlerini Firestore ile Flutter'da uygulamak için.

---

## Paketler
```yaml
cloud_firestore: ^5.x.x
firebase_storage: ^12.x.x
image_picker: ^1.x.x
cached_network_image: ^3.x.x
uuid: ^4.x.x
```

---

## Mevcut Yapı
```
lib/features/listings/
├── data/
│   └── listing_repository.dart
├── domain/
│   ├── listing_model.dart
│   └── listing_category.dart     # Enum
└── presentation/
    ├── home_screen.dart           # İlan listesi
    ├── listing_detail_screen.dart
    ├── create_listing_screen.dart
    └── listings_controller.dart   # Riverpod
```

---

## İlan Modeli
```dart
// lib/features/listings/domain/listing_model.dart
class ListingModel {
  final String id;
  final String ownerId;
  final String title;
  final String description;
  final ListingCategory category;
  final List<String> imageUrls;
  final String wantedItem;      // Karşılığında ne istiyor
  final GeoPoint location;
  final String geohash;         // Geofencing için
  final ListingStatus status;   // active, reserved, completed
  final DateTime createdAt;
}

enum ListingCategory {
  electronics,
  clothing,
  books,
  furniture,
  sports,
  toys,
  other
}

enum ListingStatus { active, reserved, completed }
```

---

## Repository Metodları
```dart
// İhtiyaç duyulacak metodlar:
Future<void> createListing(ListingModel listing)
Future<void> updateListing(ListingModel listing)
Future<void> deleteListing(String listingId)
Stream<List<ListingModel>> getNearbyListings(GeoPoint center, double radiusKm)
Stream<List<ListingModel>> getUserListings(String userId)
Future<ListingModel?> getListingById(String listingId)
Future<List<String>> uploadImages(List<File> images, String listingId)
```

---

## Firestore Sorgu Örneği
```dart
// Kullanıcının kendi ilanları
firestore
  .collection('listings')
  .where('ownerId', isEqualTo: userId)
  .where('status', isEqualTo: 'active')
  .orderBy('createdAt', descending: true)
```

---

## Firebase Storage Yapısı
```
listings/{listingId}/
  ├── image_0.jpg
  ├── image_1.jpg
  └── image_2.jpg
```

---

## Yapay Zekadan İstek Örneği
```
"PROJECT_CONTEXT.md ve skill_02_listings.md dosyalarına göre,
create_listing_screen.dart ekranını oluştur.
Ekranda şunlar olmalı: başlık, açıklama, kategori dropdown,
maksimum 5 fotoğraf yükleme, ve 'karşılığında ne istiyorum' alanı."
```
